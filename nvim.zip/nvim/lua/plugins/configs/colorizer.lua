require('colorizer').setup({
    user_default_options = {
        tailwind = true
    }
})
