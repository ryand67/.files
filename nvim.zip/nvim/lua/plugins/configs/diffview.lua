require("diffview").setup({
	use_icons = true,
	view = {
		merge_tool = {
			layout = "diff3_mixed",
		},
	},
})
