require("oil").setup({
	view_options = {
		show_hidden = true,
	},
	preview = {
		update_on_cursor_moved = true,
	},
})
